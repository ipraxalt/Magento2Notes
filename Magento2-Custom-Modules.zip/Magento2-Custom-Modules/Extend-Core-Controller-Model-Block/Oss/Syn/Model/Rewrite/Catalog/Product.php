<?php
    /**
     * Syn Catalog Product Rewrite Model
     *
     * @category    Oss
     * @package     Oss_Syn
     * @author      Laxmi
     *
     */
    namespace Oss\Syn\Model\Rewrite\Catalog;
 
    class Product extends \Magento\Catalog\Model\Product
    {
        public function isSalable()
        {
			
            // Do your stuff here
            return parent::isSalable();
        }
 
    }