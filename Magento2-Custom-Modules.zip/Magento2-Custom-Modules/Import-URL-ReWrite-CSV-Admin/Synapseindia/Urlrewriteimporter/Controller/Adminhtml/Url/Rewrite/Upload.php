<?php
/*
 *Synapseindia_Urlrewriteimporter
 * @category   Synapseindia
 * @package    Synapseindia_Urlrewriteimporter
 * @copyright  Copyright (c) 2017 Synapseindia
 * @license    Synapseindia
 * @version    1.0.0
 */
namespace Synapseindia\Urlrewriteimporter\Controller\Adminhtml\Url\Rewrite;

use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;

class Upload extends \Magento\UrlRewrite\Controller\Adminhtml\Url\Rewrite
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * Upload constructor.
     *
     * @param Action\Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context $context,
        PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('URL Rewrite Importer'));
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }
}
