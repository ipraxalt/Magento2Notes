<?php
/*
 * Synapseindia_Urlrewriteimporter

 * @category   Synapseindia
 * @package    Synapseindia_Urlrewriteimporter
 * @copyright  Copyright (c) 2017 Synapseindia
 * @license    Synapseindia
 * @version    1.0.0
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Synapseindia_Urlrewriteimporter',
    __DIR__
);
