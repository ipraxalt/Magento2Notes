<?php
// @codingStandardsIgnoreFile

/*
 * Synapseindia_Urlrewriteimporter

 * @category   Synapseindia
 * @package    Synapseindia_Urlrewriteimporter
 * @copyright  Copyright (c) 2017 Synapseindia
 * @license    https://github.com/Synapseindia/magento2-urlrewriteimporter/blob/master/LICENSE.md
 * @version    1.0.0
 */
namespace Synapseindia\Urlrewriteimporter\Block\Adminhtml\Urlrewrite\Edit;

use Magento\Backend\Block\Widget\Tabs as WidgetTabs;

class Tabs extends WidgetTabs
{
    protected function _construct()
    {
        parent::_construct();
        $this->setId('urlrewrite_import_general');
        $this->setDestElementId('edit_form');
        $this->setTitle('Url Rewrite Importer');
    }

    /**
     * Add General tab
     * @return \Magento\Backend\Block\Widget\Tabs
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'general',
            [
                'label' => __('General'),
                'title' => __('General'),
                'content' => $this->getLayout()->createBlock(
                    'Synapseindia\Urlrewriteimporter\Block\Adminhtml\Urlrewrite\Edit\Tab\General'
                )->toHtml(),
                'active' => true
            ]
        );
        return parent::_beforeToHtml();
    }
}
