<?php
/*
 * Synapseindia_Urlrewriteimporter

 * @category   Synapseindia
 * @package    Synapseindia_Urlrewriteimporter
 * @copyright  Copyright (c) 2017 Synapseindia
 * @license   Synapseindia
 * @version    1.0.0
 */
namespace Synapseindia\Urlrewriteimporter\Plugin;

use Magento\Backend\Block\Widget\Button\ButtonList;
use Magento\Framework\View\Element\AbstractBlock;

class Toolbar
{
    /**
     * Add Import button
     * @param \Magento\Backend\Block\Widget\Button\Toolbar\Interceptor $subject
     * @param AbstractBlock $block
     * @param ButtonList $buttonList
     * @return array
     */
    public function beforePushButtons(
        \Magento\Backend\Block\Widget\Button\Toolbar\Interceptor $subject,
        AbstractBlock $block,
        ButtonList $buttonList
    ) {
        if ($block instanceof \Magento\UrlRewrite\Block\GridContainer) {
            $buttonList->add('import', [
                'label' => __('Import'),
                'onclick' => 'setLocation(\'' .$block->getUrl('*/url_rewrite/upload'). '\')',
                'class' => 'import'
            ]);
        }
        return [$block, $buttonList];
    }
}
