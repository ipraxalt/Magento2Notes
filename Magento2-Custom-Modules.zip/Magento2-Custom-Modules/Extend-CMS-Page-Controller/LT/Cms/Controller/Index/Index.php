<?php
namespace LT\Cms\Controller\Index;

class Index extends \Magento\Cms\Controller\Index\Index
{
    /**
     * CMS
     * @return void
     * @throws \Exception
     */
   
    public function execute($coreRoute = null){
        echo "extended test";die;
    }
   
   
   
   
}