<?php
/**
 * MageClass_ClickAndCollect Magento Extension
 *
 * @category    MageClass
 * @package     MageClass_ClickAndCollect
 * @author      Milan Stojanov <milan.stojanov@outlook.com>
 * @website    http://www.mageclass.com
 */

namespace MageClass\ClickAndCollect\Model\Checkout;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use MageClass\ClickAndCollect\Model\ResourceModel\Store\CollectionFactory;

class DataProvider implements ConfigProviderInterface
{
    const XPATH_MAPS_API_KEY    = 'mageclass_clickandcollect/general/maps_api_key';
    const XPATH_DEFAULT_LATITUDE    = 'mageclass_clickandcollect/general/default_latitude';
    const XPATH_DEFAULT_LONGITUDE   = 'mageclass_clickandcollect/general/default_longitude';
    const XPATH_DEFAULT_ZOOM        = 'mageclass_clickandcollect/general/default_zoom';

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \MageClass\ClickAndCollect\Model\ResourceModel\Store\CollectionFactory
     */
    protected $storeCollectionFactory;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        CollectionFactory $storeCollectionFactory,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->storeManager = $storeManager;
        $this->storeCollectionFactory = $storeCollectionFactory;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $store = $this->getStoreId();
        $mapsApiKey = $this->scopeConfig->getValue(self::XPATH_MAPS_API_KEY, ScopeInterface::SCOPE_STORE, $store);
        $defaultLatitude = $this->scopeConfig->getValue(self::XPATH_DEFAULT_LATITUDE, ScopeInterface::SCOPE_STORE, $store);
        $defaultLongitude = $this->scopeConfig->getValue(self::XPATH_DEFAULT_LONGITUDE, ScopeInterface::SCOPE_STORE, $store);
        $defaultZoom = $this->scopeConfig->getValue(self::XPATH_DEFAULT_ZOOM, ScopeInterface::SCOPE_STORE, $store);
		/*
		getting pickup store from dpd api
		author: Raju
		*/
		$BASE="https://api.dpdgroup.co.uk";

$method = '/organisation/pickuplocation/?filter=nearAddress&countryCode=GB&searchPageSize=5&searchPage=1&searchCriteria=&maxDistance=10&searchAddress=B694DA';
//$method = '/user/?action=login';

$url = $BASE.$method;

$options = array(
    'http' => array(
        'method'  => 'GET',
        'Host'  => 'api.dpdgroup.co.uk',
        'header'=>  "Content-Type: application/json\r\n".
                    "Accept: application/json\r\n".
                    "Authorization: Basic ". base64_encode("DSmith:MYPassWd66") ."\r\n".
                    "GEOClient: account/123456\r\n".
                    "GEOSession: 1234567890ABCDEFGHIJK\r\n".
                    "Content-Length: 0\r\n"
      )
);

$context     = stream_context_create($options);
$result      = file_get_contents($url, false, $context);
$response    = json_decode($result);
if(count($response->data->results)){
	 foreach($response->data->results as $arrs){
		$daysArr = $arrs->pickupLocation->pickupLocationAvailability->pickupLocationOpenWindow;
		$data = array();
		foreach($daysArr as $days){
			$data[$days->pickupLocationOpenWindowDay]['start_time'][] = $days->pickupLocationOpenWindowStartTime;
			$data[$days->pickupLocationOpenWindowDay]['end_time'][] = $days->pickupLocationOpenWindowEndTime;
		}
		$dayStr = "Monday: ".$data[1]['start_time'][0]." - ".$data[1]['end_time'][1]."\nTuesday: ".$data[2]['start_time'][0]." - ".$data[2]['end_time'][1]."\nWednesday: ".$data[3]['start_time'][0]." - ".$data[3]['end_time'][1]."\nThursday: ".$data[4]['start_time'][0]." - ".$data[4]['end_time'][1]."\nFriday: ".$data[5]['start_time'][0]." - ".$data[5]['end_time'][1];
		if(isset($data[6])){$dayStr .= "\nSaturday: ".$data[6]['start_time'][0]." - ".$data[6]['end_time'][1];}else{ $dayStr .= "\nSaturday: CLOSED";}
		if(isset($data[7])){$dayStr .= "\nSunday: ".$data[7]['start_time'][0]." - ".$data[7]['end_time'][1];}else{$dayStr .= "\nSunday: CLOSED";}
		$item[] = array("store_id"=>$arrs->pickupLocation->pickupLocationCode,"name"=>$arrs->pickupLocation->address->organisation,"address"=>$arrs->pickupLocation->address->street." \n ".$arrs->pickupLocation->address->town,
					   "working_time"=>$dayStr,"latitude"=>$arrs->pickupLocation->addressPoint->latitude,"longitude"=>$arrs->pickupLocation->addressPoint->longitude,"created_at"=>$arrs->pickupLocation->pickupLocationAvailability->pickupLocationActiveStart,"updated_at"=>"2017-12-12 07:06:14","is_active"=>"1");
    }
}

$data = array("totalRecords"=>count($response->data->results),"items"=>$item);

/* end getting list from dpd api*/		
		
        $config = [
            'shipping' => [
                'select_store' => [
                    'maps_api_key'   => $mapsApiKey,
                    'lat'   => (float)$defaultLatitude,
                    'lng'   => (float)$defaultLongitude,
                    'zoom'  => (int)$defaultZoom,
                    'stores' => json_encode($data) //$this->getStores()
                ]
            ]
        ];
		//print_r($config);exit;
        return $config;
    }

    public function getStoreId()
    {
        return $this->storeManager->getStore()->getStoreId();
    }

    public function getStores()
    {
        $stores = $this->storeCollectionFactory
            ->create()
            ->addActiveFilter()
            ->toArray();
        return \Zend_Json::encode($stores);
    }
}